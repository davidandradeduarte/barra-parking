<?php
    $db_connection = pg_connect("host=localhost dbname=spatial_barra_parking user=root password=root");
?>

